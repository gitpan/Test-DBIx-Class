$VAR1 = [
  {
    'Person' => [
      [
        'name',
        'age',
        'email'
      ],
      [
        'John',
        '40',
        'john@nowehere.com'
      ],
      [
        'Vincent',
        '15',
        'vincent@home.com'
      ],
      [
        'Vanessa',
        '35',
        'vanessa@school.com'
      ]
    ],
  },
  {
    'Company' => [
      [
        'name',
      ],
      [
        'Acme',
      ],
    ],
  },
];
