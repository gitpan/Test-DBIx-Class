$VAR1 = {
  'schema_class' => 'Test::DBIx::Class::Example::Schema'
};
