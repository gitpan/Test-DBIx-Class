$VAR1 = {
  'c' => '3',
  'a' => '5',
  'config_path' => [
    't',
    'etc',
    'example',
    'schema3'
  ]
};
